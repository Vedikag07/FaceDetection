import cv2
import os
import numpy as np  # Import numpy
from datetime import datetime

# Create the screenshots directory if it doesn't exist
if not os.path.exists("screenshots"):
    os.makedirs("screenshots")

# Load the pre-trained deep learning model for face detection
modelFile = "res10_300x300_ssd_iter_140000.caffemodel"
configFile = "deploy.prototxt"
net = cv2.dnn.readNetFromCaffe(configFile, modelFile)

# Initialize webcam video capture (0 is usually the default webcam)
video_capture = cv2.VideoCapture(0)

# Check if the webcam is opened correctly
if not video_capture.isOpened():
    print("Error: Could not open webcam.")
    exit()

# Variable to store the previous detected faces
previous_faces = []

while True:
    # Capture frame-by-frame
    ret, frame = video_capture.read()

    # Check if the frame was captured correctly
    if not ret:
        print("Error: Failed to capture image from webcam.")
        break

    # Get the frame height and width
    (h, w) = frame.shape[:2]

    # Prepare the frame for deep learning face detection
    blob = cv2.dnn.blobFromImage(frame, 1.0, (300, 300), (104.0, 177.0, 123.0))

    # Set the input for the neural network
    net.setInput(blob)

    # Perform forward pass to get face detections
    detections = net.forward()

    faces = []
    for i in range(0, detections.shape[2]):
        confidence = detections[0, 0, i, 2]

        # Only consider detections with confidence greater than 0.6
        if confidence > 0.6:
            # Compute the (x, y)-coordinates of the bounding box for the face
            box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
            (x, y, x1, y1) = box.astype("int")

            # Draw a rectangle around the face
            cv2.rectangle(frame, (x, y), (x1, y1), (255, 0, 0), 2)

            # Add face to the list of detected faces
            faces.append((x, y, x1 - x, y1 - y))

    # Display the number of faces detected on the frame
    cv2.putText(frame, f'People Count: {len(faces)}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    # Logic to take screenshot when a new face enters
    if len(faces) > 0:
        # Take a screenshot only if the number of faces or positions of faces has changed
        if len(faces) != len(previous_faces) or not all((abs(x1 - x2) < 50 and abs(y1 - y2) < 50) for (x1, y1, _, _) in faces for (x2, y2, _, _) in previous_faces):
            timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            screenshot_path = f"screenshots/face_detected_{timestamp}.png"
            cv2.imwrite(screenshot_path, frame)
            print(f"Screenshot saved: {screenshot_path}")

        # Update the previous_faces to the current detected faces
        previous_faces = faces

    # Display the frame with detected faces
    cv2.imshow('Face Detection', frame)

    # Break the loop when 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture and close all OpenCV windows
video_capture.release()
cv2.destroyAllWindows()
